//(c) A+ Computer Science
// www.apluscompsci.com

//methods example 2 and 3

import static java.lang.System.*;

public class Turkey
{
   public void speak()
   {
      out.println("gobble-gobble");
   }

   public void sayName()
   {
      out.println("big bird");
      
      //what does the following line do??
      //speak();	
   }   
   	
   //create a new method
   
   //go to the TurkeyRunner and 
   //call the new method	
}